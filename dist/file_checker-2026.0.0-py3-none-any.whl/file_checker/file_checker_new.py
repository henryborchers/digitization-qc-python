"""Checks that files are consistent with DS conventions."""

import os
import sys
from datetime import date


def main():
    print('This program checks that files are consistent with DS conventions for archival and cataloged collections:'
          '\n\t- All files are either .tifs or .jp2s'
          '\n\t- File names do not contain any spaces'
          '\n\t- File names contain a hyphen'
          '\n\t- File names contain the appropriate level of padding (3 or 8 digits)'
          '\n\t- File names are sequential'
          '\n\t- All files that are in the access directory are also present in the corresponding preservation directory,'
          ' and vice versa.')

    directory = input('\nPlease enter the directory (e.g. /Volumes/digitize/project/QAqueue/session) in which your '
                      'files are stored: ')
    access_directory, directories, pres_directory, report_location = get_directories(directory)

    file_type = input('\nEnter file type ["A" for Archival or "C" for Cataloged]: ')
    run_file_type_check(file_type)
    with open(report_location, 'a') as outfile:
        make_report_header(directories, outfile)

        error_list = check_filenames(directories, file_type)
        for error in error_list:
            print(error, file=outfile)

        access_list_trimmed, pres_list_trimmed = make_file_number_lists(access_directory, pres_directory)
        matching_error_list = validate_files(access_list_trimmed, pres_list_trimmed)

        for error in matching_error_list:
            print(error, file=outfile)

        total_errors = len(error_list) + len(matching_error_list)

        print(f'{total_errors} discrepancies were discovered. Detailed report saved to {report_location}')


def get_directories(directory):
    day = str(date.today())
    report_title = f'{day}_file_checker_report.txt'

    directories = []

    access_directory = ''
    pres_directory = ''
    report_location = ''
    if sys.platform == 'win32':
        access_directory = f'{directory}\\access'
        pres_directory = f'{directory}\\preservation'
        desktop_path = os.path.expanduser('~\\Desktop')
        report_location = f'{desktop_path}\\{report_title}'
    if sys.platform == 'darwin':
        access_directory = f'{directory}/access'
        pres_directory = f'{directory}/preservation'
        desktop_path = os.path.expanduser('~/Desktop')
        report_location = f'{desktop_path}/{report_title}'

    if not os.path.isdir(access_directory) or not os.path.isdir(pres_directory):
        print(f'{access_directory} and/or {pres_directory} does not exist. '
              f'\nThis program is ending. Please run it again with correct input.')
        exit()
    directories.append(access_directory)
    directories.append(pres_directory)
    return access_directory, directories, pres_directory, report_location


def make_report_header(directories, outfile):
    print('REPORT FOR THE FOLLOWING DIRECTORIES:', file=outfile)
    for directory in directories:
        print(f'\t{directory}', file=outfile)
    print('\n', file=outfile)


def run_file_type_check(file_type):
    while file_type.casefold() != 'A'.casefold() and file_type.casefold() != 'C'.casefold():
        print(f'ERROR: Invalid file type. You entered {file_type}.'
              f'\nThis program is ending. Please run it again with correct input.')
        exit()
    return file_type


def check_filenames(directories, file_type):
    error_list = []

    for directory in directories:
        file_list = os.listdir(directory)
        file_tree = {}
        parts = 0
        for file in file_list:
            filename, suffix = file.split('.')
            if suffix != 'tif' and suffix != 'tiff' and suffix != 'jp2':
                error_list.append(f'{directory}/{file} is not a tif or jp2 file.')
                continue
            if ' ' in filename:
                error_list.append(
                    f'{file} in {directory} does not adhere to the correct naming convention (no spaces allowed).')
                continue
            if '-' in filename:
                prefix, file_number = filename.split('-')
                if str(prefix) not in file_tree:
                    file_tree[str(prefix)] = [file_number]
                else:
                    file_tree[prefix].append(file_number)
                if file_type.casefold() == 'A'.casefold():
                    if len(file_number) != 3:
                        error_list.append(
                            f'{file} in {directory} does not adhere to the correct naming convention (3 '
                            f'digits after hyphen).')
                    prefix_parts = prefix.split('_')
                    if len(prefix_parts) != 4:
                        error_list.append(
                            f'{file} in {directory} does not adhere to the correct naming convention (collection_box_folder_item-pad)')
                    for part in prefix_parts:
                        parts += 1
                        if parts > 1 and len(part) != 3:
                            error_list.append(f'{file} in {directory} does not adhere to the correct naming '
                                        f'convention (3 digits for box number, folder number, and item number).')

                if file_type.casefold() == 'C'.casefold() and len(file_number) != 8:
                    error_list.append(
                        f'{file} in {directory} does not adhere to the correct naming convention (8 '
                        f'digits after hyphen).')
            else:
                error_list.append(f'{file} in {directory} does not adhere to the correct naming '
                                  f'conventions (missing hyphen).')
        sequence_errors = check_sequential(file_tree, directory)
        if sequence_errors:
            error_list.extend(sequence_errors)

    return error_list


def check_sequential(file_tree, directory):
    sequence_errors = []
    for prefix in file_tree:
        file_numbers = file_tree[prefix]
        numbers_only_list = []
        for file_number in file_numbers:
            stripped_file = str(file_number).lstrip('0')
            if stripped_file != '':
                numbers_only_list.append(int(stripped_file))
        numbers_only_list.sort()
        for position_counter, file in enumerate(numbers_only_list):
            if position_counter != 0:
                if int(file) != (int(position_counter) + 1):
                    sequence_errors.append(
                        f'Files in the directory {directory} with the prefix {prefix} ending in {position_counter} and '
                        f'{file} are not sequential.')
            else:
                pass
    return sequence_errors


def validate_files(access_list_trimmed, pres_list_trimmed):
    matching_error_list = []

    pres_missing = list(filter(lambda x: x not in pres_list_trimmed, access_list_trimmed))
    access_missing = list(filter(lambda x: x not in access_list_trimmed, pres_list_trimmed))

    if pres_missing:
        matching_error_list.append(f'\nThe following files are present in the access directory, but are not present in '
              f'the preservation directory: {pres_missing}')

    if access_missing:
        matching_error_list.append(f'The following files are present in the preservation directory, but are not present '
              f'in the access directory: {access_missing}')

    return matching_error_list


def make_file_number_lists(access_directory, pres_directory):
    access_list = os.listdir(access_directory)
    access_list_trimmed = []
    for file in access_list:
        trimmed_file = file.split('.')[0]
        access_list_trimmed.append(trimmed_file)
    pres_list = os.listdir(pres_directory)
    pres_list_trimmed = []
    for file in pres_list:
        trimmed_file = file.split('.')[0]
        pres_list_trimmed.append(trimmed_file)
    return access_list_trimmed, pres_list_trimmed


if __name__ == '__main__':
    main()
